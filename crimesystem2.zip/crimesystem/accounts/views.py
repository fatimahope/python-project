'''from django.shortcuts import render
def register(request):
    return render(request,"register.html")

def login(request):
    return render(request,"login.html")'''

from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from .models import Missing_Person,Complaint

def login(request):
    if request.method=='POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username)
        print(password)
        user=auth.authenticate(username=username,password=password)
        print(user)
        if user is not None:
            auth.login(request,user)
            return redirect("user_enter")
        else:
            messages.info(request,'Invalid credentials')
            return redirect('login')

    else:
        return render(request, 'login.html')

# Create your views here.
def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,"Username already taken!!!....try some different name")
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request,"Email already taken")
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name,last_name=last_name)
                user.save()
                print("User created!!")
                return redirect('login')
        else:
            messages.info(request,"Password not matching!!")
            return redirect('register')

    else:
        return render(request, 'register.html')


def logout(request):
    auth.logout(request)
    return redirect('/')

def user_enter(request):
        missing=Missing_Person.objects.all()
        return render(request,'user.html',{'missing':missing})

def complaint(request):
    if request.method == "POST":
        username=request.user #current user
        vname=request.POST['vname'] #victim's name
        police_station=request.POST['p_station'] 
        com_type=request.POST['type'] #complaint type
        desc=request.POST['subject']   #description
        fname=request.POST.get('fname','Not specified') #name of predator
        print(fname)
        address=request.POST.get('address','Not specified')
        complaint=Complaint(vname=vname, police_station=police_station, com_type=com_type, desc=desc,fname=fname, username=username,address=address)
        complaint.save()
        print("Complaint added!")
        messages.info(request,"Complaint added successfully!")
        return redirect('complaint')
    else:
        return render(request,'complaint.html')