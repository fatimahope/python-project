from django.urls import path
from . import views

urlpatterns = [
    path('register', views.register,name="register"),
    path('login', views.login,name="login"),
    path('logout', views.logout,name="logout"),
    path('user_enter',views.user_enter,name="user_enter"),
    path('complaint',views.complaint,name="complaint"),
]