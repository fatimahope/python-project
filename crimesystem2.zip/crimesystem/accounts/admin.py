from django.contrib import admin
from .models import Missing_Person,Complaint
# Register your models here.
admin.site.register(Missing_Person)
admin.site.register(Complaint)