from django.db import models

# Create your models here.
class Add_Missing_Person(models.Model):
        name=models.CharField(max_length=150)
        img=models.ImageField(upload_to="pics")
        height=models.IntegerField()
        gender=models.CharField(max_length=10,default="")
        age=models.IntegerField()
        wearing=models.CharField(max_length=200)
        missing_date=models.DateField(auto_now=False)
        