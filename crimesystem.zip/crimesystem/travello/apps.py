from django.apps import AppConfig


class TravelloConfig(AppConfig):
    name = 'travello'
