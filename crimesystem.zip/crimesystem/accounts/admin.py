from django.contrib import admin
from .models import Missing_Person,Complaint,Wanted_Person
# Register your models here.

admin.site.register(Missing_Person)
admin.site.register(Complaint)
admin.site.register(Wanted_Person)

