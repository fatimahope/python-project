from django.urls import path
from . import views

urlpatterns = [
    path('register', views.register,name="register"),
    path('login', views.login,name="login"),
    path('logout', views.logout,name="logout"),
    path('user_enter',views.user_enter,name="user_enter"),
    path('complaint',views.complaint,name="complaint"),
    path('display_complaint',views.display_complaint,name="display_complaint"),
    path('display_missing',views.display_missing,name="display_missing"),
    path('delete_complaint',views.delete_complaint,name="delete_complaint"),
    path('delete_complaint',views.delete_complaint,name="delete_complaint"),
    path('display_wanted',views.display_wanted,name="display_wanted"),
    path('missing_info',views.missing_info,name="missing_info"),
]