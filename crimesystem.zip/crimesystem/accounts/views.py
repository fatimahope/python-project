'''from django.shortcuts import render
def register(request):
    return render(request,"register.html")

def login(request):
    return render(request,"login.html")'''

from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from .models import Missing_Person,Complaint,Wanted_Person
from django.contrib import messages

def login(request):
    if request.method=='POST':
        username = request.POST['username']
        password = request.POST['password']
        user=auth.authenticate(username=username,password=password)
        print(user)
        if user is not None:
            auth.login(request,user)
            return redirect("user_enter")
        else:
            messages.info(request,'Invalid credentials')
            return redirect(request.META['HTTP_REFERER'])

    else:
        return render(request, 'login.html')

# Create your views here.
def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,"Username already taken!!!....try some different name")
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request,"Email already taken")
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name,last_name=last_name)
                user.save()
                print("User created!!")
                return redirect('login')
        else:
            messages.info(request,"Password not matching!!")
            return redirect(request.META['HTTP_REFERER'])

    else:
        return render(request, 'register.html')


def logout(request):
    auth.logout(request)
    return redirect('/')

def user_enter(request):
        if request.user.is_authenticated:
            missing=Missing_Person.objects.all()
            return render(request,'user.html',{'missing':missing})
        else:
            return render(request,'index.html')

def complaint(request):
    if request.user.is_authenticated:
        com_id=request.session.get('com_id',None)
        if request.method == "POST":
            username=request.user #current user
            vname=request.POST['vname'] #victim's name
            police_station=request.POST['p_station'] 
            com_type=request.POST['type'] #complaint type
            desc=request.POST['subject']   #description
            fname=request.POST.get('fname') #name of predator
            if fname=="":
                fname="Not specified"
            contact_no=request.POST['contact_no']
            if len(contact_no) <10:
                messages.info(request,"Please enter valid Contact Number!!!")
                return redirect(request.META['HTTP_REFERER'])
            try:
                cn=int(contact_no)
            except ValueError as e:
                messages.info(request,"Please enter only digits in contact number!!!")
                return redirect(request.META['HTTP_REFERER'])
            address=request.POST.get('address')
            if address=="":
                address="Not specified"
            reply="None"
            complaint=Complaint(vname=vname, police_station=police_station, com_type=com_type, desc=desc,fname=fname, username=username,address=address ,contact_no=contact_no,reply=reply)
            complaint.save()
            if com_id!=None:
                Complaint.objects.filter(id=com_id).delete()
            return redirect('display_complaint')
        else:
            return render(request,'complaint.html')
    else:
        return render(request,'index.html')

def display_complaint(request):
    m=[]
    if request.user.is_authenticated:
        m.append(str(request.session.get('m',"")))
        request.session['m']="" #Here i am giving it null string so that m vairable in request.session['m'] should not hold the message of the previous function call.
        com_id=int(request.session.get('com_id',-1))
        request.session['com_id']=-1 #Even here giving the value -1 because variable shouldnt hold the previous function call value
        sys=request.session.get('sys',None)
        username=request.user
        class_name="Complaint"
        complaint=Complaint.objects.filter(username=username)
        if com_id!=-1:
            print(com_id)
            complaint=Complaint.objects.filter(id=com_id)
        return render(request,'user.html',{'complaint':complaint,'class_name':class_name,'com_id':com_id,'sys':sys,'m':m})
    else:
        return render(request,'index.html')


def missing_info(request):
    class_name="Missing_info"
    miss_id=request.POST.get('miss_id')
    print(miss_id)
    system=request.POST.get('system',None)
    print(system)
    subject=request.POST.get('subject')
    time=request.POST.get('time')
    date=request.POST.get('date')
    print(subject)
    if system=="INFO":
        print("Working")
        return redirect(request.META['HTTP_REFERER'])
    else:
        missing=Missing_Person.objects.filter(id=miss_id)
        if missing is not None:
            print('abcpqr')
        return render(request,'user.html',{'missing':missing,'class_name':class_name}) 


def display_missing(request):
    class_name="Missing"
    if request.user.is_authenticated:
        missing=Missing_Person.objects.all()
        return render(request,'user.html',{'missing':missing,'class_name':class_name})
    else:
        return render(request,'index.html')

def delete_complaint(request): #this method is also used for editing the complaint
    if request.user.is_authenticated:
        com_id=request.POST.get('name') #complaint id
        obj=Complaint.objects.get(id=com_id)
        system=request.POST.get('system',None)
        request.session['com_id'] = com_id

        if system=="delete" or 'YES' in request.POST or 'NO' in request.POST:
            request.session['sys']="delete"
            if obj.reply!="None":
                request.session['m']="Cannot delete this complaint."
                return redirect('display_complaint')
            if 'YES' in request.POST:
                Complaint.objects.filter(id=com_id).delete()
                request.session['com_id']=-1
                return redirect('display_complaint')
            elif 'NO' in request.POST:
                request.session['com_id']=-1
                return redirect('display_complaint')
            else:
                request.session['m']="Are you sure you want to delete this complaint?"
                return redirect('display_complaint')

        elif system=="edit":
            request.session['sys']="edit"
            if obj.reply=="None":
                new_obj=obj
                return render(request,'complaint.html',{'new_obj':new_obj})
            else:
                request.session['m']="Cannot edit this complaint."
                return redirect('display_complaint')
    else:
        return render(request,'index.html')

def display_wanted(request):
    if request.user.is_authenticated:
        class_name="Wanted"
        wanted=Wanted_Person.objects.all()
        return render(request,'user.html',{'wanted':wanted,'class_name':class_name})
    else:
        return render(request,'index.html')
